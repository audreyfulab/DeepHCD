def main():
    print("Hello from deephcd!")


if __name__ == "__main__":
    main()
